**willpyre.app** 
--------------

.. automodule:: willpyre.app
   :members:
   :undoc-members:
   :show-inheritance: