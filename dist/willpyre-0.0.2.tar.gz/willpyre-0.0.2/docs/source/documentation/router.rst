**willpyre.router**
-----------------

.. automodule:: willpyre.router
   :members:
   :undoc-members:
   :show-inheritance: