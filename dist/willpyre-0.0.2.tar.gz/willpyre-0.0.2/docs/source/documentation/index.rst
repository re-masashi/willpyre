Documentation
=============

**Module contents**
-------------------

.. automodule:: willpyre
   :members:
   :undoc-members:
   :show-inheritance:

.. toctree ::
   router
   structure
   app

