**willpyre.structure**
---------------------

.. automodule:: willpyre.structure
   :members:
   :undoc-members:
   :show-inheritance: